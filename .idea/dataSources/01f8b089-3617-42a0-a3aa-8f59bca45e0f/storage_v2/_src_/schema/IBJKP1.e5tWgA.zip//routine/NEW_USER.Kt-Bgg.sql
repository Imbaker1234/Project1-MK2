create PROCEDURE new_user
(
username VARCHAR2,
password VARCHAR2,
firstname VARCHAR2,
lastname VARCHAR2,
email VARCHAR2
)
IS
BEGIN
    INSERT INTO ers_users (ers_users_id, ers_username, ers_password, user_first_name, user_last_name, user_email, user_role_id)
    VALUES (users_seq.nextval, username, password, firstname, lastname, email, 1);
    COMMIT;
END;
/

